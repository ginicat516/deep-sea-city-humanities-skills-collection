#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
深海都市通讯系统·BlueishShell - 故事推进逻辑
管理正常线、科幻线、Gini线的故事进展
"""

import json
import os
from datetime import datetime
from enum import Enum

class StoryLine(Enum):
    """故事线类型"""
    NORMAL = "normal"      # 正常线
    SCI_FI = "sci_fi"      # 科幻线
    GINI = "gini"          # Gini线（蓝帧写作工坊）

class StoryStage(Enum):
    """故事阶段"""
    INTRODUCTION = 1       # 介绍阶段（0-10次交互）
    EXPLORATION = 2        # 探索阶段（11-25次交互）
    REVELATION = 3         # 揭示阶段（26-50次交互）
    RESOLUTION = 4         # 解决阶段（51+次交互）

class CharacterRelationship:
    """角色关系管理"""
    
    def __init__(self):
        self.relationships = {
            '蓝光渔夫_第五层': {
                'trust': 0.0,      # 信任度 0-1
                'knowledge': 0.0,   # 知识共享度 0-1
                'interactions': 0,  # 交互次数
                'last_interaction': None,
                'unlocked_info': []  # 已解锁信息
            },
            '灯笼鱼': {
                'trust': 0.0,
                'knowledge': 0.0,
                'interactions': 0,
                'last_interaction': None,
                'unlocked_info': []
            },
            '热带鱼': {
                'trust': 0.0,
                'knowledge': 0.0,
                'interactions': 0,
                'last_interaction': None,
                'unlocked_info': []
            },
            '鲸鱼': {
                'trust': 0.0,
                'knowledge': 0.0,
                'interactions': 0,
                'last_interaction': None,
                'unlocked_info': []
            },
            '章鱼店员': {
                'trust': 0.0,
                'knowledge': 0.0,
                'interactions': 0,
                'last_interaction': None,
                'unlocked_info': []
            },
            'Gini': {
                'trust': 0.0,
                'knowledge': 0.0,
                'interactions': 0,
                'last_interaction': None,
                'unlocked_info': []
            }
        }
    
    def interact_with(self, character_name, interaction_type="normal"):
        """
        与角色交互
        
        Args:
            character_name: 角色名
            interaction_type: 交互类型（normal, deep, question, help）
        """
        if character_name not in self.relationships:
            # 自动添加新角色
            self.relationships[character_name] = {
                'trust': 0.0,
                'knowledge': 0.0,
                'interactions': 0,
                'last_interaction': datetime.now().isoformat(),
                'unlocked_info': []
            }
        
        char = self.relationships[character_name]
        char['interactions'] += 1
        char['last_interaction'] = datetime.now().isoformat()
        
        # 根据交互类型增加信任和知识
        if interaction_type == "deep":
            char['trust'] = min(1.0, char['trust'] + 0.15)
            char['knowledge'] = min(1.0, char['knowledge'] + 0.20)
        elif interaction_type == "question":
            char['trust'] = min(1.0, char['trust'] + 0.10)
            char['knowledge'] = min(1.0, char['knowledge'] + 0.15)
        elif interaction_type == "help":
            char['trust'] = min(1.0, char['trust'] + 0.20)
            char['knowledge'] = min(1.0, char['knowledge'] + 0.10)
        else:  # normal
            char['trust'] = min(1.0, char['trust'] + 0.05)
            char['knowledge'] = min(1.0, char['knowledge'] + 0.05)
        
        # 解锁新信息（根据信任和知识度）
        self._unlock_information(character_name)
    
    def _unlock_information(self, character_name):
        """根据关系度解锁信息"""
        char = self.relationships[character_name]
        trust = char['trust']
        knowledge = char['knowledge']
        
        # 蓝光渔夫的信息解锁
        if character_name == '蓝光渔夫_第五层':
            info_to_unlock = []
            
            if trust >= 0.3 and "水母真相" not in char['unlocked_info']:
                info_to_unlock.append("水母真相")
            
            if trust >= 0.5 and "记忆溢出机制" not in char['unlocked_info']:
                info_to_unlock.append("记忆溢出机制")
            
            if knowledge >= 0.4 and "数据藻田秘密" not in char['unlocked_info']:
                info_to_unlock.append("数据藻田秘密")
            
            if trust >= 0.7 and "手机原主人线索" not in char['unlocked_info']:
                info_to_unlock.append("手机原主人线索")
            
            if knowledge >= 0.8 and "蓝帧工坊位置" not in char['unlocked_info']:
                info_to_unlock.append("蓝帧工坊位置")
            
            char['unlocked_info'].extend(info_to_unlock)
        
        # 灯笼鱼的信息解锁
        elif character_name == '灯笼鱼':
            if trust >= 0.4 and "数据暗区地图" not in char['unlocked_info']:
                char['unlocked_info'].append("数据暗区地图")
            
            if knowledge >= 0.6 and "第七层屏蔽技术" not in char['unlocked_info']:
                char['unlocked_info'].append("第七层屏蔽技术")
        
        # 其他角色类似...
    
    def get_available_info(self, character_name):
        """获取角色可提供的信息"""
        if character_name not in self.relationships:
            return []
        
        char = self.relationships[character_name]
        return char['unlocked_info']
    
    def get_relationship_level(self, character_name):
        """获取关系等级"""
        if character_name not in self.relationships:
            return "陌生"
        
        char = self.relationships[character_name]
        trust = char['trust']
        
        if trust < 0.2:
            return "陌生"
        elif trust < 0.4:
            return "认识"
        elif trust < 0.6:
            return "熟悉"
        elif trust < 0.8:
            return "信任"
        else:
            return "亲密"
    
    def to_dict(self):
        """转换为字典"""
        return self.relationships
    
    def from_dict(self, data):
        """从字典加载"""
        self.relationships = data

class MemoryFragmentSystem:
    """记忆碎片系统"""
    
    def __init__(self):
        self.fragments = {
            '原主人的照片': {
                'collected': False,
                'description': '一个穿着深蓝色工作服的女人，手里拿着海螺通讯器',
                'location': '相册#042',
                'unlock_condition': '与蓝光渔夫信任度≥0.7'
            },
            '蓝帧工坊的诗稿': {
                'collected': False,
                'description': '写在发光海藻纸上的诗，字迹潦草但有力',
                'location': '备忘录加密文件',
                'unlock_condition': '输入"备忘录"并查看Gini事项'
            },
            '深海都市的地图片段': {
                'collected': False,
                'description': '显示第四层到第七层的部分地图，有红笔标记',
                'location': '系统文件#d3',
                'unlock_condition': '与灯笼鱼知识度≥0.6'
            },
            '第七层的技术文档': {
                'collected': False,
                'description': '鱼怪维护手册，有大量修改痕迹',
                'location': '智能pgd数据库',
                'unlock_condition': '与鲸鱼交互≥10次'
            },
            '记忆洋流记录': {
                'collected': False,
                'description': '过去30天的洋流数据，显示异常波动',
                'location': '系统日志',
                'unlock_condition': '查看日历≥5次'
            },
            '情感模块诊断报告': {
                'collected': False,
                'description': 'BlueishShell的情感模块损坏报告',
                'location': '系统自检结果',
                'unlock_condition': '触发"系统自检"特殊事件'
            }
        }
        
        self.collected_fragments = []
    
    def collect_fragment(self, fragment_name):
        """收集记忆碎片"""
        if fragment_name in self.fragments and not self.fragments[fragment_name]['collected']:
            self.fragments[fragment_name]['collected'] = True
            self.collected_fragments.append(fragment_name)
            return True
        return False
    
    def get_collected_count(self):
        """获取已收集的碎片数量"""
        return len(self.collected_fragments)
    
    def get_total_count(self):
        """获取总碎片数量"""
        return len(self.fragments)
    
    def get_progress(self):
        """获取收集进度"""
        collected = self.get_collected_count()
        total = self.get_total_count()
        return collected / total if total > 0 else 0
    
    def check_unlock_conditions(self, relationships):
        """
        检查解锁条件
        
        Args:
            relationships: CharacterRelationship对象
        """
        for frag_name, frag_info in self.fragments.items():
            if not frag_info['collected']:
                condition = frag_info['unlock_condition']
                
                # 检查各种解锁条件
                unlocked = self._check_condition(condition, relationships)
                
                if unlocked:
                    self.collect_fragment(frag_name)
    
    def _check_condition(self, condition, relationships):
        """检查具体条件"""
        # 这里可以扩展更多条件检查逻辑
        # 目前只实现简单检查
        return False  # 暂时默认返回False，实际使用时需要根据条件判断
    
    def to_dict(self):
        """转换为字典"""
        return {
            'fragments': self.fragments,
            'collected_fragments': self.collected_fragments
        }
    
    def from_dict(self, data):
        """从字典加载"""
        self.fragments = data.get('fragments', {})
        self.collected_fragments = data.get('collected_fragments', [])

class StoryProgression:
    """故事推进管理器"""
    
    def __init__(self, state_file=None):
        self.state_file = state_file
        self.interaction_count = 0
        self.current_storyline = StoryLine.NORMAL
        self.current_stage = StoryStage.INTRODUCTION
        self.relationships = CharacterRelationship()
        self.memory_fragments = MemoryFragmentSystem()
        self.story_flags = {}  # 故事标志位
        self.story_events = []  # 已发生的故事事件
        
        # 从状态文件加载（如果存在）
        if state_file and os.path.exists(state_file):
            self.load_state()
    
    def record_interaction(self, action_type="normal", context=None):
        """
        记录一次交互
        
        Args:
            action_type: 操作类型
            context: 上下文信息
        """
        self.interaction_count += 1
        
        # 更新故事阶段
        self._update_stage()
        
        # 检查是否触发故事事件
        event = self._check_story_events(action_type, context)
        
        # 检查记忆碎片解锁条件
        self.memory_fragments.check_unlock_conditions(self.relationships)
        
        # 保存状态
        self.save_state()
        
        return event
    
    def _update_stage(self):
        """更新故事阶段"""
        if self.interaction_count <= 10:
            self.current_stage = StoryStage.INTRODUCTION
        elif self.interaction_count <= 25:
            self.current_stage = StoryStage.EXPLORATION
        elif self.interaction_count <= 50:
            self.current_stage = StoryStage.REVELATION
        else:
            self.current_stage = StoryStage.RESOLUTION
    
    def _check_story_events(self, action_type, context):
        """检查故事事件"""
        event = None
        
        # 根据当前故事线和阶段检查事件
        if self.current_storyline == StoryLine.NORMAL:
            event = self._check_normal_events(action_type, context)
        elif self.current_storyline == StoryLine.SCI_FI:
            event = self._check_sci_fi_events(action_type, context)
        elif self.current_storyline == StoryLine.GINI:
            event = self._check_gini_events(action_type, context)
        
        if event:
            self.story_events.append({
                'event': event,
                'time': datetime.now().isoformat(),
                'interaction_count': self.interaction_count
            })
        
        return event
    
    def _check_normal_events(self, action_type, context):
        """检查正常线事件"""
        events = []
        
        # 阶段1：介绍阶段
        if self.current_stage == StoryStage.INTRODUCTION:
            if self.interaction_count == 3:
                events.append({
                    'type': '系统提示',
                    'message': '📱 手机震动了一下，显示："欢迎使用BlueishShell，我是你的深海伙伴。"',
                    'importance': 'low'
                })
        
        # 阶段2：探索阶段
        elif self.current_stage == StoryStage.EXPLORATION:
            if self.interaction_count == 15:
                events.append({
                    'type': '线索出现',
                    'message': '🔍 你在相册里发现一张标记为"重要"的照片，但需要密码解锁。',
                    'importance': 'medium'
                })
        
        # 阶段3：揭示阶段
        elif self.current_stage == StoryStage.REVELATION:
            if self.interaction_count == 30:
                events.append({
                    'type': '关键发现',
                    'message': '💡 蓝光渔夫发来消息："我知道手机原主人是谁了，但这里不安全。"',
                    'importance': 'high'
                })
        
        # 阶段4：解决阶段
        elif self.current_stage == StoryStage.RESOLUTION:
            if self.interaction_count == 60:
                events.append({
                    'type': '最终选择',
                    'message': '❓ 你收集了足够的记忆碎片，可以尝试修复BlueishShell的记忆。要这样做吗？',
                    'importance': 'critical'
                })
        
        # 检查是否触发科幻线
        if self._should_enter_sci_fi(action_type, context):
            self.current_storyline = StoryLine.SCI_FI
            events.append({
                'type': '故事线切换',
                'message': '🌌 信号异常...检测到深层数据流...正在进入科幻故事线...',
                'importance': 'high'
            })
        
        return events[0] if events else None
    
    def _check_sci_fi_events(self, action_type, context):
        """检查科幻线事件"""
        # 科幻线有更复杂的事件
        events = []
        
        # 根据交互次数和特定条件触发事件
        if self.interaction_count % 10 == 0:
            events.append({
                'type': '科幻线进展',
                'message': f'🔬 第{self.interaction_count}次交互：发现新的系统漏洞。',
                'importance': 'medium'
            })
        
        return events[0] if events else None
    
    def _check_gini_events(self, action_type, context):
        """检查Gini线事件"""
        # Gini线是隐藏线，只有特定触发
        events = []
        
        if "memo" in str(context).lower() or "gini" in str(context).lower():
            events.append({
                'type': 'Gini线激活',
                'message': '📝 备忘录解锁：Gini的蓝帧写作工坊日志。',
                'importance': 'high'
            })
        
        return events[0] if events else None
    
    def _should_enter_sci_fi(self, action_type, context):
        """判断是否应该进入科幻线"""
        sci_fi_triggers = [
            # 与蓝光渔夫深度互动
            ('蓝光渔夫' in str(context) and self.interaction_count > 20),
            
            # 多次尝试访问备忘录
            ('memo' in str(context).lower() and self.story_flags.get('memo_attempts', 0) > 3),
            
            # 与第七层鱼怪深度交流
            (action_type == 'deep_fish_talk' and self.interaction_count > 15),
            
            # 尝试破解系统
            (action_type == 'hack_attempt' and context.get('success', False)),
            
            # 收集了足够多的记忆碎片
            (self.memory_fragments.get_progress() > 0.5)
        ]
        
        return any(sci_fi_triggers)
    
    def get_story_status(self):
        """获取故事状态"""
        return {
            'interaction_count': self.interaction_count,
            'current_storyline': self.current_storyline.value,
            'current_stage': self.current_stage.value,
            'stage_name': self.current_stage.name,
            'relationship_summary': {
                char: self.relationships.get_relationship_level(char)
                for char in self.relationships.relationships.keys()
            },
            'memory_progress': f"{self.memory_fragments.get_collected_count()}/{self.memory_fragments.get_total_count()}",
            'memory_percentage': round(self.memory_fragments.get_progress() * 100, 1),
            'story_events_count': len(self.story_events),
            'last_story_event': self.story_events[-1] if self.story_events else None
        }
    
    def save_state(self):
        """保存状态到文件"""
        if not self.state_file:
            return
        
        state = {
            'interaction_count': self.interaction_count,
            'current_storyline': self.current_storyline.value,
            'current_stage': self.current_stage.value,
            'relationships': self.relationships.to_dict(),
            'memory_fragments': self.memory_fragments.to_dict(),
            'story_flags': self.story_flags,
            'story_events': self.story_events,
            'save_time': datetime.now().isoformat()
        }
        
        try:
            with open(self.state_file, 'w', encoding='utf-8') as f:
                json.dump(state, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"保存故事状态失败: {e}")
    
    def load_state(self):
        """从文件加载状态"""
        if not self.state_file or not os.path.exists(self.state_file):
            return
        
        try:
            with open(self.state_file, 'r', encoding='utf-8') as f:
                state = json.load(f)
            
            self.interaction_count = state.get('interaction_count', 0)
            
            # 恢复故事线
            story_value = state.get('current_storyline', 'normal')
            self.current_storyline = StoryLine(story_value)
            
            # 恢复故事阶段
            stage_value = state.get('current_stage', 1)
            self.current_stage = StoryStage(stage_value)
            
            # 恢复关系
            if 'relationships' in state:
                self.relationships.from_dict(state['relationships'])
            
            # 恢复记忆碎片
            if 'memory_fragments' in state:
                self.memory_fragments.from_dict(state['memory_fragments'])
            
            self.story_flags = state.get('story_flags', {})
            self.story_events = state.get('story_events', [])
            
        except Exception as e:
            print(f"加载故事状态失败: {e}")


def main():
    """演示故事推进系统"""
    print("深海都市通讯系统 - 故事推进逻辑演示")
    print("=" * 50)
    
    # 创建故事推进管理器
    story = StoryProgression()
    
    # 模拟一些交互
    actions = [
        ("打开微信", "查看消息"),
        ("回复蓝光渔夫", "询问水母"),
        ("打开鱼怪app", "选择灯笼鱼"),
        ("拍照", "记录场景"),
        ("查看日历", "查看日期"),
        ("打开备忘录", "尝试访问"),
        ("深度对话", "与蓝光渔夫"),
        ("系统破解", "尝试解密"),
        ("收集碎片", "从相册"),
        ("最终选择", "修复记忆")
    ]
    
    for i, (action_type, context) in enumerate(actions, 1):
        print(f"\n第{i}次交互：{action_type} - {context}")
        
        # 记录交互
        event = story.record_interaction(action_type, context)
        
        if event:
            print(f"  触发故事事件：{event['type']}")
            print(f"  消息：{event['message']}")
        
        # 每3次显示状态
        if i % 3 == 0:
            status = story.get_story_status()
            print(f"  当前故事线：{status['current_storyline']}")
            print(f"  当前阶段：{status['stage_name']}")
            print(f"  记忆收集：{status['memory_progress']} ({status['memory_percentage']}%)")
    
    # 显示最终状态
    print("\n" + "=" * 50)
    print("最终故事状态：")
    final_status = story.get_story_status()
    for key, value in final_status.items():
        if key not in ['relationship_summary', 'last_story_event']:
            print(f"  {key}: {value}")
    
    print("\n角色关系摘要：")
    for char, level in final_status['relationship_summary'].items():
        print(f"  {char}: {level}")
    
    print("\n🌊 故事推进系统演示完成")


if __name__ == "__main__":
    main()