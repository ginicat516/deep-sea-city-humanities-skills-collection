#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
深海都市通讯系统·BlueishShell - 随机触发算法
每5次有效交互触发一次随机事件
"""

import random
import json
import os
from datetime import datetime

class RandomTriggerSystem:
    """随机触发系统"""
    
    def __init__(self, state_file=None):
        """
        初始化随机触发系统
        
        Args:
            state_file: 状态文件路径，用于保存用户状态
        """
        self.interaction_count = 0
        self.last_trigger_count = 0
        self.trigger_threshold = 5  # 每5次触发一次
        self.triggered_events = []
        self.state_file = state_file
        
        # 事件类型及概率
        self.event_types = {
            'message_notification': 0.40,  # 40% 消息通知
            'guidance_prompt': 0.30,       # 30% 引导提示
            'environment_change': 0.20,    # 20% 环境变化
            'special_event': 0.10         # 10% 特殊事件
        }
        
        # 事件库
        self.events_library = self._load_events_library()
        
        # 从状态文件加载（如果存在）
        if state_file and os.path.exists(state_file):
            self.load_state()
    
    def _load_events_library(self):
        """加载事件库"""
        return {
            'message_notification': [
                {
                    'id': 'wx_msg_1',
                    'type': '微信消息',
                    'description': '微信有人给你发了一条信息，是否查看',
                    'content': '未知联系人：“今天的水温有点奇怪，你感觉到了吗？”',
                    'weight': 1.0
                },
                {
                    'id': 'wx_msg_2',
                    'type': '微信消息',
                    'description': '微信有人给你发了一条信息，是否查看',
                    'content': '蓝光渔夫_第五层：“那只水母又出现了，这次在数据藻田的东北角。”',
                    'weight': 0.8
                },
                {
                    'id': 'pgd_msg_1',
                    'type': '鱼怪消息',
                    'description': '智能pgd有鱼怪给你发送了一条消息，是否接收',
                    'content': '灯笼鱼请求连接，说它知道"蓝帧"的事情。',
                    'weight': 1.0
                },
                {
                    'id': 'pgd_msg_2',
                    'type': '鱼怪消息',
                    'description': '智能pgd有鱼怪给你发送了一条消息，是否接收',
                    'content': '热带鱼发来情感分析报告：“当前情绪波动指数：0.72，建议休息。”',
                    'weight': 0.7
                },
                {
                    'id': 'rednote_notice',
                    'type': '小红书通知',
                    'description': '小红书给你弹出一条通知，是否查看',
                    'content': '深海都市美食地图更新：第八层沉船区发现可食用发光藻，但有居民说吃了会做奇怪的梦。',
                    'weight': 0.9
                },
                {
                    'id': 'system_weather',
                    'type': '系统消息',
                    'description': '深海都市天气预警：今晚有记忆洋流过境，建议备份重要数据',
                    'content': '记忆洋流预计今晚20:00-22:00过境，可能引发数据波动和情感溢出。',
                    'weight': 0.6
                }
            ],
            
            'guidance_prompt': [
                {
                    'id': 'album_guide',
                    'type': '相册引导',
                    'description': '要打开相册看看吗？里面有107张未分类的照片',
                    'content': '相册里有107张照片，大部分是模糊的海底景象，但有3张标有"重要记忆"标签。',
                    'weight': 1.0
                },
                {
                    'id': 'journal_guide',
                    'type': '日志引导',
                    'description': '要写一篇日志吗？今天是深海纪年第112日',
                    'content': '深海纪年第112日，洋流方向偏南，气压稳定。适合记录重要发现。',
                    'weight': 0.9
                },
                {
                    'id': 'memo_guide',
                    'type': '备忘录引导',
                    'description': '备忘录有3条待办事项，其中一条标红',
                    'content': '待办事项：1. 联系蓝光渔夫（正常） 2. 备份记忆数据（正常） 3. 联系Gini - 蓝帧写作工坊材料缺失（标红）',
                    'weight': 0.8
                },
                {
                    'id': 'settings_guide',
                    'type': '设置引导',
                    'description': '系统设置里有个"记忆修复"选项，要查看吗？',
                    'content': '记忆修复功能：可以尝试修复损坏的记忆片段，成功率72%。',
                    'weight': 0.7
                }
            ],
            
            'environment_change': [
                {
                    'id': 'temp_change',
                    'type': '水温变化',
                    'description': '水温检测：当前23°C（比上次上升1度）',
                    'content': '水温从22°C上升到23°C，可能受到上层热排放影响。',
                    'weight': 1.0
                },
                {
                    'id': 'location_change',
                    'type': '位置变化',
                    'description': '位置信号波动：可能正在向下层移动',
                    'content': 'GPS信号显示当前位置：深海都市第四层与第五层交界处。',
                    'weight': 0.8
                },
                {
                    'id': 'signal_change',
                    'type': '信号变化',
                    'description': '通讯信号：弱（受到第七层干扰）',
                    'content': '检测到第七层的屏蔽信号，通讯质量下降30%。',
                    'weight': 0.9
                },
                {
                    'id': 'battery_change',
                    'type': '电量变化',
                    'description': '剩余电量：68%（节能模式已启用）',
                    'content': '电量消耗正常，预计剩余使用时间：12小时。',
                    'weight': 0.6
                }
            ],
            
            'special_event': [
                {
                    'id': 'memory_fragment',
                    'type': '记忆碎片',
                    'description': '屏幕突然闪了一下，显示一张模糊的脸："你还记得我吗？"',
                    'content': '记忆碎片#042：一个穿着深蓝色工作服的女人，手里拿着海螺通讯器。',
                    'weight': 1.0
                },
                {
                    'id': 'encrypted_data',
                    'type': '异常数据',
                    'description': '收到一条加密信息，解密需要输入密码或联系蓝光渔夫',
                    'content': '加密信息长度：342字节，加密算法：深海都市标准加密v2.3。',
                    'weight': 0.8
                },
                {
                    'id': 'system_self_check',
                    'type': '系统自检',
                    'description': 'BlueishShell开始自检：记忆完整度72%，情感模块待修复',
                    'content': '自检结果：硬件正常，软件正常，记忆完整度72%，情感模块损坏38%。',
                    'weight': 0.7
                },
                {
                    'id': 'external_interference',
                    'type': '外界干扰',
                    'description': '检测到第七层的扫描信号，建议暂时关闭通讯',
                    'content': '第七层扫描信号强度：中等，频率：7.3kHz，目的：未知。',
                    'weight': 0.9
                }
            ]
        }
    
    def record_interaction(self, interaction_type="normal"):
        """
        记录一次交互
        
        Args:
            interaction_type: 交互类型，normal为有效交互
        """
        if interaction_type == "normal":
            self.interaction_count += 1
            self.save_state()
    
    def should_trigger(self):
        """
        检查是否应该触发随机事件
        
        Returns:
            bool: 是否触发
        """
        if self.interaction_count - self.last_trigger_count >= self.trigger_threshold:
            return True
        return False
    
    def generate_random_event(self):
        """
        生成随机事件
        
        Returns:
            dict: 事件信息，或None（如果不应该触发）
        """
        if not self.should_trigger():
            return None
        
        # 选择事件类型
        event_type = self._select_event_type()
        
        # 从该类型中选择具体事件
        event = self._select_event_from_type(event_type)
        
        if event:
            # 更新触发计数
            self.last_trigger_count = self.interaction_count
            self.triggered_events.append({
                'event_id': event['id'],
                'trigger_time': datetime.now().isoformat(),
                'interaction_count': self.interaction_count
            })
            self.save_state()
        
        return event
    
    def _select_event_type(self):
        """根据概率选择事件类型"""
        rand = random.random()
        cumulative = 0.0
        
        for event_type, probability in self.event_types.items():
            cumulative += probability
            if rand <= cumulative:
                return event_type
        
        # 默认返回消息通知
        return 'message_notification'
    
    def _select_event_from_type(self, event_type):
        """从指定类型中选择具体事件"""
        if event_type not in self.events_library:
            return None
        
        events = self.events_library[event_type]
        
        # 基于权重的选择
        total_weight = sum(event['weight'] for event in events)
        rand = random.uniform(0, total_weight)
        
        cumulative = 0.0
        for event in events:
            cumulative += event['weight']
            if rand <= cumulative:
                return event
        
        return events[0] if events else None
    
    def get_recent_events(self, count=5):
        """获取最近触发的事件"""
        return self.triggered_events[-count:] if self.triggered_events else []
    
    def get_event_statistics(self):
        """获取事件统计信息"""
        stats = {
            'total_interactions': self.interaction_count,
            'total_triggers': len(self.triggered_events),
            'trigger_rate': len(self.triggered_events) / max(self.interaction_count, 1),
            'last_trigger': self.triggered_events[-1] if self.triggered_events else None,
            'next_trigger_at': self.last_trigger_count + self.trigger_threshold
        }
        return stats
    
    def save_state(self):
        """保存状态到文件"""
        if not self.state_file:
            return
        
        state = {
            'interaction_count': self.interaction_count,
            'last_trigger_count': self.last_trigger_count,
            'triggered_events': self.triggered_events,
            'save_time': datetime.now().isoformat()
        }
        
        try:
            with open(self.state_file, 'w', encoding='utf-8') as f:
                json.dump(state, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"保存状态失败: {e}")
    
    def load_state(self):
        """从文件加载状态"""
        if not self.state_file or not os.path.exists(self.state_file):
            return
        
        try:
            with open(self.state_file, 'r', encoding='utf-8') as f:
                state = json.load(f)
            
            self.interaction_count = state.get('interaction_count', 0)
            self.last_trigger_count = state.get('last_trigger_count', 0)
            self.triggered_events = state.get('triggered_events', [])
        except Exception as e:
            print(f"加载状态失败: {e}")
    
    def reset(self):
        """重置系统"""
        self.interaction_count = 0
        self.last_trigger_count = 0
        self.triggered_events = []
        self.save_state()


def get_random_event_example():
    """获取随机事件示例（用于演示）"""
    trigger_system = RandomTriggerSystem()
    
    # 模拟5次交互
    for i in range(5):
        trigger_system.record_interaction()
    
    event = trigger_system.generate_random_event()
    
    if event:
        print(f"🎲 触发随机事件：{event['type']}")
        print(f"📱 {event['description']}")
        print(f"📄 内容：{event['content']}")
        print(f"📊 统计：总交互{trigger_system.interaction_count}次，触发{len(trigger_system.triggered_events)}次")
    else:
        print("未触发随机事件")
    
    return event


if __name__ == "__main__":
    # 演示随机事件系统
    print("深海都市通讯系统 - 随机触发算法演示")
    print("=" * 50)
    
    event = get_random_event_example()
    
    print("\n📋 事件库统计：")
    trigger_system = RandomTriggerSystem()
    for event_type, events in trigger_system.events_library.items():
        print(f"  {event_type}: {len(events)}个事件")
    
    print("\n🌊 随机触发系统已就绪")