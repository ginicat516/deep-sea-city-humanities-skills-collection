# 深海都市引路鱼鲲技能打包脚本
# 用法: .\package.ps1

$ErrorActionPreference = "Stop"

# 配置
$SkillDir = $PSScriptRoot
$SkillName = "深海都市引路鱼鲲"
$OutputZip = "$env:USERPROFILE\Desktop\$SkillName.zip"

Write-Host "正在打包 $SkillName 技能..." -ForegroundColor Cyan

# 检查必要文件
if (-not (Test-Path "$SkillDir\SKILL.md")) {
    Write-Host "错误: 未找到 SKILL.md 文件" -ForegroundColor Red
    exit 1
}

# 创建临时目录
$TempDir = "$env:TEMP\$SkillName"
if (Test-Path $TempDir) {
    Remove-Item -Path $TempDir -Recurse -Force
}
New-Item -ItemType Directory -Path $TempDir | Out-Null

# 复制所有文件
Write-Host "复制文件到临时目录..." -ForegroundColor Yellow
Get-ChildItem -Path $SkillDir -Exclude "package.*" | ForEach-Object {
    if ($_.PSIsContainer) {
        Copy-Item -Path $_.FullName -Destination $TempDir -Recurse -Force
    } else {
        Copy-Item -Path $_.FullName -Destination $TempDir -Force
    }
}

# 创建ZIP文件
Write-Host "创建ZIP文件: $OutputZip" -ForegroundColor Yellow
Compress-Archive -Path "$TempDir\*" -DestinationPath $OutputZip -Force

# 清理临时文件
Remove-Item -Path $TempDir -Recurse -Force

# 显示结果
Write-Host "`n打包完成！" -ForegroundColor Green
Write-Host "技能包位置: $OutputZip" -ForegroundColor Green
Write-Host "`n技能包含以下文件:" -ForegroundColor Cyan
Get-ChildItem -Path $SkillDir -Exclude "package.*" | ForEach-Object {
    if ($_.PSIsContainer) {
        Write-Host "  📁 $($_.Name)/"
    } else {
        Write-Host "  📄 $($_.Name)"
    }
}

Write-Host "`n文件大小: $(Get-Item $OutputZip | Select-Object -ExpandProperty Length | ForEach-Object { [math]::Round($_/1KB, 2) }) KB" -ForegroundColor Cyan
Write-Host "`n可以上传到 GitHub 或分享给其他人使用。" -ForegroundColor Green