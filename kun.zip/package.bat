@echo off
chcp 65001 >nul
echo 正在打包 深海都市引路鱼鲲 技能...

set SKILL_DIR=%~dp0
set SKILL_NAME=深海都市引路鱼鲲
set OUTPUT_ZIP="%USERPROFILE%\Desktop\%SKILL_NAME%.zip"

echo 检查目录结构...
if not exist "%SKILL_DIR%SKILL.md" (
    echo 错误: 未找到 SKILL.md 文件
    pause
    exit /b 1
)

echo 创建临时目录...
set TEMP_DIR=%TEMP%\%SKILL_NAME%
if exist "%TEMP_DIR%" rmdir /s /q "%TEMP_DIR%"
mkdir "%TEMP_DIR%"

echo 复制文件...
xcopy "%SKILL_DIR%*" "%TEMP_DIR%\" /E /I /Y

echo 创建ZIP文件...
cd /d "%TEMP_DIR%\.."
powershell -Command "Compress-Archive -Path '%SKILL_NAME%' -DestinationPath %OUTPUT_ZIP% -Force"

echo 清理临时文件...
rmdir /s /q "%TEMP_DIR%"

echo.
echo 打包完成！
echo 技能包位置: %OUTPUT_ZIP%
echo.
echo 技能包含以下文件:
dir "%SKILL_DIR%" /b
echo.
pause